import { CouncilDashboard } from '@/components/council/CouncilDashboard';

const Index = () => {
  return <CouncilDashboard />;
};

export default Index;
